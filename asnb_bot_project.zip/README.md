Upload your CSV in this folder and deploy via Render.
